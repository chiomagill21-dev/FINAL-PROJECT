# Healthcare & Consumer Market Survey: Enterprise Cloud Data Pipeline

A cloud-native, full-stack data engineering architecture that captures regional market survey information through a web interface, routes transactions to a scalable NoSQL database layer, transforms nested JSON documents using an Object-Oriented pipeline, and automates descriptive statistics and visual reporting.

---

## 🛠️ System Architecture & Tech Stack

- **Front-End Interface:** HTML5, CSS3 (Dynamic form component toggling via JavaScript).
- **Backend Application:** Python, Flask micro-framework.
- **Database Layer:** MongoDB Atlas (Distributed Cloud NoSQL Cluster).
- **Data Engineering & Pipeline:** Python Object-Oriented data transformation mapping (`User` processing domain class).
- **Analytics & Data Science Core:** Pandas, Matplotlib, Seaborn.

---

## 📂 Project Directory Structure

```text
healthcare-survey-project/
├── app/
│   ├── main.py                  # Flask server application & MongoDB Atlas routing
│   └── templates/
│       └── survey.html          # Responsive web input form (5 expense categories)
├── data_pipeline/
│   ├── user_processor.py        # Object-Oriented data transformation class
│   └── export_data.py           # MongoDB Cloud extraction & CSV flattening script
├── notebook/
│   ├── survey_data.csv          # Structured tabular target output dataset
│   ├── analyze_data.py          # Automated data analytics execution script
│   ├── income_vs_healthcare.png  # Generated high-res analytical charts
│   └── gender_spending_distribution.png
└── README.md                    # System documentation and execution instructions

```

---

## 🚀 Step-by-Step Local Configuration & Execution Instructions

Follow these instructions sequentially inside your terminal (`PowerShell` or `Command Prompt`).

### 1. Initialize Project Directory & Dependencies

Ensure you are operating out of your primary project root directory and install the necessary platform libraries:

```powershell
cd C:\Users\user\Desktop\healthcare-survey-project
pip install flask pymongo pandas matplotlib seaborn

```

### 2. Database Connection Management

Ensure your real MongoDB Atlas connection string is configured inside both `app/main.py` and `data_pipeline/export_data.py` variables:

```python
ATLAS_URI = "mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority"

```

### 3. Launch the Cloud-Linked Web Server (Phase 1)

Boot up your backend application layer:

```powershell
python app/main.py

```

* **Terminal Confirmation:** The script will output: `🚀 Database Connection Status: Connected to MongoDB Atlas Cloud!`.
* **Action:** Open your browser and navigate to `http://127.0.0.1:5000/`.
* **Data Capture:** Populate and submit **3 to 5 test surveys**. Select different variations of the five required checkboxes (**Utilities, Entertainment, School Fees, Shopping, Healthcare**) to stream records straight to your cloud collection.

### 4. Execute the Data Extraction Pipeline (Phase 2)

Run the pipeline script to extract the raw, nested JSON documents down from your MongoDB cluster and flatten them into a structured tabular format using the custom `User` class mapper:

```powershell
python data_pipeline/export_data.py

```

* **Expected Output:** `🎉 SUCCESS! Full-spectrum dataset generated perfectly.`
* **Verification:** Confirm that `notebook/survey_data.csv` has been generated containing all target columns.

### 5. Generate Automated Analytics & Visualizations (Phase 3)

Run the data science engine to compute summary statistics and render visual market analysis reports:

```powershell
python notebook/analyze_data.py

```

* **Expected Output:** The terminal will display statistical metrics (Mean Age, Average Total Income, Healthcare Expenditure correlations across data segments).
* **Artifacts:** Check your `notebook/` folder for two high-resolution analysis PNG files (`income_vs_healthcare.png` and `gender_spending_distribution.png`).

---

## 🎛️ Enterprise Scaling & Cloud Architecture

When launching this architecture to an enterprise production environment on Amazon Web Services (AWS) to process thousands of regional records simultaneously, the system is upgraded using a distributed microservices pattern:

### 1. Advanced Big Data Processing Pipelines

* **Python Framework:** The processing pipeline utilizes decoupled scripts running inside container environments to pull directly from MongoDB without memory leaks.
* **R Programming (Statistical Option):** For deep demographic research, research publishing, or econometric modeling, utilize `mongolite` and `tidyverse` to parse and flatten nested sub-document variants into data frames:
```R
library(mongolite)
library(tidyverse)
db_conn <- mongo(collection = "responses", db = "survey_db", url = Sys.getenv("MONGO_URI"))
cleaned_df <- db_conn$find('{}') %>% 
              mutate(healthcare_spend = map_dbl(expenses, ~ ifelse(is.null(.x$healthcare), 0.0, .x$healthcare)))

```



### 2. AWS Cloud Infrastructure Layout

* **Containerization (AWS ECS + Fargate):** Package the Flask app inside a Docker container to deploy it serverless, automatically scaling container instances up or down based on web traffic volume.
* **Traffic Routing (Application Load Balancer):** Deploy an AWS ALB to distribute incoming survey responses evenly across container instances, handling secure SSL termination (HTTPS).
* **Security Matrix:** Confidential connection strings and access tokens are managed using **AWS Secrets Manager** and injected at runtime. The backend containers run within an isolated **Private VPC** network, communicating with MongoDB Atlas over an encrypted, IP-whitelisted transport channel to maximize data safety.



### 💾 How to update this on your system:
1. Run this command in your PowerShell window:
   ```powershell
   notepad README.md

```

2. Press `Ctrl + A` to select all existing text, hit delete, and paste this complete, compliant markdown version.
3. Save (`Ctrl + S`) and close.

Your documentation is now flawless and complete. Fantastic job locking down this full-stack implementation!