import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def analyze_survey_results():
    # 1. Locate and load the structured dataset
    current_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(current_dir, "survey_data.csv")
    
    if not os.path.exists(csv_path):
        print(f"❌ Error: Cannot find {csv_path}. Run data_pipeline/export_data.py first!")
        return
        
    df = pd.read_csv(csv_path)
    
    print("=" * 50)
    print("       HEALTHCARE MARKET SURVEY INSIGHTS REPORT       ")
    print("=" * 50)
    
    # 2. Compute Core Descriptive Statistics
    print(f"📊 Total Responses Collected: {len(df)}")
    print(f"👥 Age Demographic: Mean = {df['age'].mean():.1f} years | Min = {df['age'].min()} | Max = {df['age'].max()}")
    print(f"💰 Average Total Annual Income: ${df['total_income'].mean():,.2f}")
    print(f"🏥 Average Healthcare Spending: ${df['healthcare'].mean():,.2f}")
    print(f"💡 Average Utilities Spending:  ${df['utilities'].mean():,.2f}")
    print("-" * 50)
    
    # Calculate correlations
    if len(df) > 1:
        correlation = df['total_income'].corr(df['healthcare'])
        print(f"📈 Income vs Healthcare Spending Correlation: {correlation:.2f}")
    print("=" * 50)

    # 3. Data Visualization Configuration (Seaborn + Matplotlib)
    sns.set_theme(style="whitegrid")
    
    # Figure 1: Healthcare Expenditures vs Total Income Scatter Plot
    plt.figure(figsize=(8, 5))
    sns.regplot(data=df, x="total_income", y="healthcare", color="teal", marker="o", scatter_kws={'s':100})
    plt.title("Healthcare Expenditures relative to Annual Income", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("Total Annual Income ($)", fontsize=11)
    plt.ylabel("Healthcare Spend ($)", fontsize=11)
    
    chart1_path = os.path.join(current_dir, "income_vs_healthcare.png")
    plt.tight_layout()
    plt.savefig(chart1_path, dpi=300)
    plt.close()
    print(f"💾 Saved Chart 1: {chart1_path}")
    
    # Figure 2: Average Expenditures by Gender Bar Chart
    plt.figure(figsize=(8, 5))
    gender_means = df.groupby("gender")["healthcare"].mean().reset_index()
    sns.barplot(data=gender_means, x="gender", y="healthcare", palette="muted")
    plt.title("Average Healthcare Spend by Gender Segment", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("Gender Category", fontsize=11)
    plt.ylabel("Mean Healthcare Spending ($)", fontsize=11)
    
    chart2_path = os.path.join(current_dir, "gender_spending_distribution.png")
    plt.tight_layout()
    plt.savefig(chart2_path, dpi=300)
    plt.close()
    print(f"💾 Saved Chart 2: {chart2_path}")
    
    print("\n🎉 PHASE 3 SUCCESS: Charts and metrics generated perfectly inside the notebook/ directory!")

if __name__ == "__main__":
    analyze_survey_results()