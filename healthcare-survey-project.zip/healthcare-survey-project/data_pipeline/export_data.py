import os
import sys
import csv
from pymongo import MongoClient

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from user_processor import User

def run_export_pipeline():
    # ⚠️ Paste your actual MongoDB Atlas connection string here
    ATLAS_URI = "mongodb+srv://mustaphaaliyu520:Fatimatu2@cluster0.3klexst.mongodb.net/?appName=Cluster0"
    
    try:
        print("🔗 Connecting to MongoDB Atlas Cloud Database...")
        client = MongoClient(ATLAS_URI, serverSelectionTimeoutMS=5000)
        db = client["survey_db"]
        survey_collection = db["responses"]
        
        total_records = survey_collection.count_documents({})
        if total_records == 0:
            print("⚠️ Cloud database collection is currently empty!")
            return
            
        print(f"🔄 Processing {total_records} documents from MongoDB Atlas...")
        
        flat_records = []
        for doc in survey_collection.find():
            user_instance = User(doc)
            flat_records.append(user_instance.to_dict())
            
        project_root = os.path.dirname(current_dir)
        target_csv_path = os.path.join(project_root, "notebook", "survey_data.csv")
        os.makedirs(os.path.dirname(target_csv_path), exist_ok=True)
        
        # Tabular structure containing all requirement criteria fields
        csv_headers = ["user_id", "age", "gender", "total_income", "utilities", "entertainment", "school_fees", "shopping", "healthcare"]
        with open(target_csv_path, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=csv_headers)
            writer.writeheader()
            writer.writerows(flat_records)
            
        print(f"\n🎉 SUCCESS! Full-spectrum dataset generated perfectly.")
        print(f"📍 File Location: {target_csv_path}")
        
    except Exception as e:
        print(f"\n❌ Pipeline failed: {str(e)}")

if __name__ == "__main__":
    run_export_pipeline()