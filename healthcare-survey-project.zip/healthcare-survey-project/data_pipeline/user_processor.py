class User:
    def __init__(self, record):
        """
        Maps nested MongoDB Atlas BSON documents seamlessly into 
        explicit Object-Oriented attributes.
        """
        self.id = str(record.get("_id"))
        self.age = int(record.get("age", 0))
        self.gender = record.get("gender", "Unknown")
        self.total_income = float(record.get("total_income", 0.0))
        
        # Handle the updated nested expenses block safely
        expenses_dict = record.get("expenses", {})
        self.utilities = float(expenses_dict.get("utilities", 0.0))
        self.entertainment = float(expenses_dict.get("entertainment", 0.0))
        self.school_fees = float(expenses_dict.get("school_fees", 0.0))
        self.shopping = float(expenses_dict.get("shopping", 0.0))
        self.healthcare = float(expenses_dict.get("healthcare", 0.0))

    def to_dict(self):
        """Flattens our domain object structure into a tabular data dictionary."""
        return {
            "user_id": self.id,
            "age": self.age,
            "gender": self.gender,
            "total_income": self.total_income,
            "utilities": self.utilities,
            "entertainment": self.entertainment,
            "school_fees": self.school_fees,
            "shopping": self.shopping,
            "healthcare": self.healthcare
        }