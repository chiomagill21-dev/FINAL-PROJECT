import os
from flask import Flask, render_template, request
from pymongo import MongoClient

base_dir = os.path.dirname(os.path.abspath(__file__))
template_dir = os.path.join(base_dir, "templates")

app = Flask(__name__, template_folder=template_dir)

# ⚠️ Paste your actual MongoDB Atlas connection string here
ATLAS_URI = "mongodb+srv://mustaphaaliyu520:Fatimatu2@cluster0.3klexst.mongodb.net/?appName=Cluster0"

try:
    client = MongoClient(ATLAS_URI, serverSelectionTimeoutMS=5000)
    db = client["survey_db"]
    survey_collection = db["responses"]
    client.admin.command('ping')
    print("🚀 Database Connection Status: Connected to MongoDB Atlas Cloud!")
except Exception as e:
    print(f"❌ Database Connection Status: Cloud Offline ({e})")

@app.route("/", methods=["GET"])
def survey_form():
    return render_template("survey.html")

@app.route("/submit", methods=["POST"])
def submit_survey():
    try:
        age = int(request.form.get("age", 0))
        gender = request.form.get("gender", "Unknown")
        total_income = float(request.form.get("total_income", 0.0))
        
        # Track all 5 requested categories dynamically
        categories = ["utilities", "entertainment", "school_fees", "shopping", "healthcare"]
        expenses = {}
        
        for cat in categories:
            if request.form.get(cat):
                amount_str = request.form.get(f"{cat}_amount", "0")
                expenses[cat] = float(amount_str) if amount_str else 0.0
            else:
                expenses[cat] = 0.0

        survey_document = {
            "age": age,
            "gender": gender,
            "total_income": total_income,
            "expenses": expenses
        }
        
        survey_collection.insert_one(survey_document)
        return "<h3>Submission Saved to Cloud Successfully!</h3><a href='/'>Submit another entry</a>"
    except Exception as e:
        return f"<h3>Database Error: {str(e)}</h3><a href='/'>Go Back</a>"

if __name__ == "__main__":
    app.run(debug=True)